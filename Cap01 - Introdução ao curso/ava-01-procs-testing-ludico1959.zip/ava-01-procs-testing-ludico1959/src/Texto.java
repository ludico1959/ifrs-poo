class Texto {
  public static String pad(String umaString, int largura, char umCaractere) {

	if (umaString.length() < largura) {
		int numeroDeCaracteresAdicionais = largura - umaString.length();

		for (int i = 0; i < numeroDeCaracteresAdicionais; i++) {
			umaString += umCaractere;
		}
	}

	return umaString;
	}
}
