class Matematica {
  public static int resto(int dividendo, int divisor) {
		int quociente;
		int resto = Integer.MAX_VALUE;

		do {
			quociente = dividendo / divisor;

			resto = dividendo - divisor * quociente;

			dividendo = resto;
		} while (divisor < resto);

    return resto;
  }

}
