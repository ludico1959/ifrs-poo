class Excel {
  public static int columnNumber(String column) {
		int columnCounter = 0;

		for (int i = 0; i < column.length(); i++) {
			columnCounter += ((int) column.charAt(i) - 64) * Math.pow(26, (column.length() - i - 1));
		}

		return columnCounter;
	}
}
