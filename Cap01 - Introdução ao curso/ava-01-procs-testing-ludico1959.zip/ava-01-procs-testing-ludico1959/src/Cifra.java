class Cifra {
  public static String decodificador(String cifra, int deslocamento) {
		String cifraDecodificada = "";
		int inicialASCII, finalASCII;

		for (int i = 0; i < cifra.length(); i++) {
			inicialASCII = (int) cifra.charAt(i);
			finalASCII = inicialASCII - deslocamento;

			if (finalASCII < 65) {
				finalASCII += 26;
			}

			cifraDecodificada += (char) finalASCII;
		}

    return cifraDecodificada;
  }

}

